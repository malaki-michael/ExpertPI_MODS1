import logging
import os
from pathlib import Path
import time

from serving_manager.api import TorchserveRestManager


MAX_WAIT_TIME = 30

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def register_model(manager: TorchserveRestManager, model_name: str, initial_workers: int = 0):
    logger.info(f"Registering model {model_name} with Torchserve with path '' and initial workers {initial_workers}")
    manager.register(model_name, path="", initial_workers=initial_workers)
    
    
def get_models_to_scale_to_1_worker(path: str):
    env_var = os.getenv("MODELS_WITH_WORKER")
    if env_var is None:
        return []
    return env_var.replace(" ", "").split(",")


def find_all_models(path: str):
    return list(Path(path).glob("*.mar"))


def register_all_models(path: str):
    manager = TorchserveRestManager(host=os.environ.get("HOST", "localhost"), inference_port="8080", management_port="8081", timeout=30)
    start_time = time.time()
    while True:
        try:
            healthy = manager.health_check()["status"] == "Healthy"
        except Exception as e:
            print(e)
            healthy = False
        if healthy:
            break
        if time.time() - start_time > MAX_WAIT_TIME:
            raise Exception("Torchserve is not healthy")
        logger.info("Torchserve is not healthy, waiting for 1 second")
        time.sleep(1)
    for model in find_all_models(path):
        num_workers = 1 if model.stem in get_models_to_scale_to_1_worker(path) else 0
        try:
            register_model(manager, model.stem, num_workers)
        except Exception as e:
            logger.error(f"Failed to register model {model.stem}: {e}")


if __name__ == "__main__":
    register_all_models("/home/stem_model/model_store")
    logger.warning("All models registered")
