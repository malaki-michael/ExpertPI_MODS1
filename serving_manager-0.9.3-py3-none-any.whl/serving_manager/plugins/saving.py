import json
import tempfile
import zipfile

import cv2
import h5py
import niquests
import numpy as np


def upload_zip(host, port, zip_path, name, metadata: dict[str, str] | None = None, timeout: float | None = None):
    """Uploads a zip file to the serving manager

    Args:
        host (str): The host of the serving manager
        port (str): The port of the serving manager
        zip_path (str): The path to the zip file
        name (str): The name of the zip file
        metadata (dict[str, str] | None, optional): The metadata of the zip file. Defaults to None.
        timeout (float | None, optional): The timeout of the request. Defaults to None.

    Returns:
        dict: The response from the serving manager
    """
    if metadata is None:
        metadata = {}

    if isinstance(metadata, dict):
        metadata = json.dumps(metadata)

    with open(zip_path, "rb") as f:
        response = niquests.post(
            f"http://{host}:{port}/save/zip",
            files={"file": f},
            params={"name": name, "metadata": metadata},
            timeout=timeout
    )
    return response.json()


def upload_image(
        host,
        port,
        image_path: str = None,
        image: np.ndarray = None,
        name: str = "simpleimage",
        metadata: dict[str, str] | None = None,
        timeout: float = 2.0
    ) -> dict:
    """Uploads an image to the serving manager

    Args:
        host (str): The host of the serving manager
        port (str): The port of the serving manager
        image_path (str, optional): The path to the image. Defaults to None.
        image (np.ndarray, optional): The image to upload. Defaults to None.
        name (str, optional): The name of the image. Defaults to "simpleimage".
        metadata (dict[str, str] | None, optional): The metadata of the image. Defaults to None.
        timeout (float, optional): The timeout of the request. Defaults to 2.0.

    Returns:
        dict: The response from the serving manager
    """
    if metadata is None:
        metadata = {}

    if isinstance(metadata, dict):
        metadata = json.dumps(metadata)

    assert image_path is not None or image is not None, "Either image_path or image should be provided"

    with open(image_path, "rb") as f:
        response = niquests.post(
            f"http://{host}:{port}/save/image",
            files={"file": f},
            params={"name": name, "metadata": metadata},
            timeout=timeout
        )
    return response.json()


def upload_hdf5(host, port, file_path: str, name: str = "simplehdf5", metadata: dict[str, str] | None = None, timeout: float | None = None):
    """Uploads an HDF5 file to the serving manager

    Args:
        host (str): The host of the serving manager
        port (str): The port of the serving manager
        file_path (str): The path to the HDF5 file
        name (str, optional): The name of the HDF5 file. Defaults to "simplehdf5".
        metadata (dict[str, str] | None, optional): The metadata of the HDF5 file. Defaults to None.
        timeout (float | None, optional): The timeout of the request. Defaults to None.

    Returns:
        dict: The response from the serving manager
    """
    if metadata is None:
        metadata = {}

    if isinstance(metadata, dict):
        metadata = json.dumps(metadata)

    with open(file_path, "rb") as f:
        response = niquests.post(
            f"http://{host}:{port}/save/hdf",
            files={"file": f},
            params={"name": name, "metadata": metadata},
            timeout=timeout
        )
    return response.json()


def upload_hdf5_data(
        host,
        port,
        data,
        name: str = "simplehdf5",
        metadata: dict[str, str] | None = None,
        dataset_name: str = "data",
        timeout: float | None = None,
    ):
    """Uploads HDF5 data to the serving manager

    Args:
        host (str): The host of the serving manager
        port (str): The port of the serving manager
        data (np.ndarray): The data to upload
        name (str, optional): The name of the data. Defaults to "simplehdf5".
        metadata (dict[str, str] | None, optional): The metadata of the data. Defaults to None.
        dataset_name (str, optional): The name of the dataset. Defaults to "data".
        timeout (float | None, optional): The timeout of the request. Defaults to None.

    Returns:
        dict: The response from the serving manager
    """
    if metadata is None:
        metadata = {}

    if isinstance(metadata, dict):
        metadata = json.dumps(metadata)

    # Use NamedTemporaryFile to ensure the file has a name
    with tempfile.NamedTemporaryFile() as f:
        with h5py.File(f.name, "w") as h5f:
            h5f.create_dataset(dataset_name, data=data)
        f.seek(0)
        # Now f.name can be used to identify the file
        with open(f.name, 'rb') as file_to_upload:
            response = niquests.post(
                f"http://{host}:{port}/save/hdf",
                files={"file": file_to_upload},
                params={"name": name, "metadata": metadata},
                timeout=timeout
            )
    return response.json()


if __name__ == "__main__":

    # Simple testing of the upload functions
    host = "localhost"
    port = "5000"


    with tempfile.NamedTemporaryFile(suffix=".zip") as f:
        with zipfile.ZipFile(f.name, "w") as z:
            z.writestr("test.txt", "Hello, World!")
        zip_file = f.name
        print("Testing upload_zip...")
        zip_response = upload_zip(host, port, zip_file, name="testzip", metadata=json.dumps({"creator": "test"}))
        print(f"Response: {zip_response}")


    image = cv2.imwrite("test.jpg", np.random.rand(100, 100, 3) * 255)

    # Test upload_zip

    # Test upload_image with image_path
    print("\nTesting upload_image with image_path...")
    image_response = upload_image(host, port, image_path="test.jpg", name="testimage", metadata={"creator": "test"})
    image_response = upload_image(host, port, image=np.random.rand(100, 100, 3) * 255, name="testimage", metadata=json.dumps({"creator": "test2"}))
    print(f"Response: {image_response}")

    # Test upload_hdf5
    print("\nTesting upload_hdf5...")
    import numpy as np
    hdf5_data = np.random.rand(100, 100)  # Example data
    hdf5_response = upload_hdf5_data(host, port, hdf5_data, name="testhdf5", metadata={"creator": "test"})
    print(f"Response: {hdf5_response}")
