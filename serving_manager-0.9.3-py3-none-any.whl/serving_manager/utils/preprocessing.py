import base64
from typing import Callable

import cv2
import numpy as np


try:
    import torch
except ImportError:
    torch = None


def decode_base64_image(base64_image: str) -> np.ndarray:
    """Decode base64 image to numpy array"""
    image_bytes = base64.b64decode(base64_image)
    image_bytes = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(image_bytes, flags=cv2.IMREAD_UNCHANGED)
    return image


def encode(np_image):
    return cv2.imencode(".jpg", np_image)[1].tobytes()


def encode_base64_image(image: np.ndarray) -> str:
    """Encode numpy array to base64 image"""
    _, buffer = cv2.imencode(".jpg", image)
    return base64.b64encode(buffer).decode("utf-8")


def max_normalization_fn(image: np.ndarray) -> np.ndarray:
    """Normalizes image by its maximum value

    Args:
        image (np.ndarray): input image

    Returns:
        np.ndarray: Normalized image
    """
    return image / np.amax(image)


def min_max_normalization_fn(image: np.ndarray) -> np.ndarray:
    """Normalizes image by its minimum and maximum value

    Args:
        image (np.ndarray): input image

    Returns:
        np.ndarray: Normalized image
    """
    return (image - np.amin(image)) / (np.amax(image) - np.amin(image))


def preprocess_image(
        image: np.ndarray,
        normalization_function: Callable[[np.ndarray], np.ndarray] = max_normalization_fn
    ) -> np.ndarray:
    """Preprocess image for inference, apply normalization and change to correct data type

    Args:
        image (np.ndarray): input image
        normalization_function (Callable[[np.ndarray], np.ndarray], optional): Function to normalize the image.
            Defaults to max_normalization_fn.

    Raises:
        NotImplementedError: In case of uknown data type

    Returns:
        np.ndarray: Preprocessed image
    """
    if isinstance(image, str):
        return preprocess_image(decode_base64_image(image), normalization_function)

    if torch is not None and isinstance(image, torch.Tensor):
        return preprocess_image(image.detach().permute(1, 2, 0).cpu().numpy(), normalization_function)

    if image.dtype == np.uint8:
        return image

    elif image.dtype in [np.float32, np.float64, np.uint16]:
        return (normalization_function(image) * 255).astype(np.uint8)

    else:
        raise NotImplementedError(f"Image type {image.dtype} is not supported")


def scale_homography_matrix(homography_matrix: np.ndarray, scale_x: float, scale_y: float) -> np.ndarray:
    """Scale homography matrix

    Args:
        homography_matrix (np.ndarray): Input homography matrix
        scale_x (float): Scale factor for x axis
        scale_y (float): Scale factor for y axis

    Returns:
        np.ndarray: Scaled homography matrix
    """
    scale_matrix = np.array([[scale_x, 0, 0], [0, scale_y, 0], [0, 0, 1]])
    return np.linalg.inv(scale_matrix) @ homography_matrix @ scale_matrix


def merge_images(src: np.ndarray, dst: np.ndarray) -> np.ndarray:
    """Merge two images into one along x axis

    Args:
        src (np.ndarray): Source image
        dst (np.ndarray): Destination image

    Returns:
        np.ndarray: Merged image
    """
    assert src.shape[1] == dst.shape[1]
    return np.concatenate([src, dst], axis=1)
