class FutureModelException(Exception):
    pass
