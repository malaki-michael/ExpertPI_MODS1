import dataclasses
import json
from typing import Optional

import numpy as np
from serving_manager.management.torchserve_rest_manager import TorchserveRestManager
from serving_manager.management.torchserve_grpc_manager import TorchserveGrpcManager
from serving_manager.utils.preprocessing import decode_base64_image


@dataclasses.dataclass
class Point:
    """Represents a 2D point with x and y coordinates.
    
    Attributes:
        x (float): The x-coordinate of the point.
        y (float): The y-coordinate of the point.
    """
    x: float
    y: float
    
    def to_list(self) -> list[float]:
        """Convert the point to a list of coordinates.
        
        Returns:
            list[float]: A list containing [x, y] coordinates.
        """
        return [self.x, self.y]


@dataclasses.dataclass
class SegmentAnythingResult:
    """Represents the result of a segment anything model inference.
    
    Attributes:
        mask (np.ndarray): The segmentation mask as a numpy array.
        score (float): The confidence score of the segmentation.
    """
    mask: np.ndarray
    score: float


@dataclasses.dataclass
class BoundingBox:
    """Represents a rectangular bounding box.
    
    Attributes:
        xstart (float): The x-coordinate of the top-left corner.
        ystart (float): The y-coordinate of the top-left corner.
        xend (float): The x-coordinate of the bottom-right corner.
        yend (float): The y-coordinate of the bottom-right corner.
    """
    xstart: float
    ystart: float
    xend: float
    yend: float
    
    def to_dict(self) -> dict:
        """Convert the bounding box to a dictionary.
        
        Returns:
            dict: Dictionary containing the bounding box coordinates.
        """
        return {
            "xstart": self.xstart,
            "ystart": self.ystart,
            "xend": self.xend,
            "yend": self.yend,
        }


@dataclasses.dataclass
class PointsPrompt:
    """Container for positive and negative point prompts.
    
    Attributes:
        positive_points (list[Point]): List of positive prompt points.
        negative_points (list[Point]): List of negative prompt points.
    """
    positive_points: list[Point]
    negative_points: list[Point]
    
    def to_dict(self) -> dict:
        """Convert the points prompt to a dictionary.
        
        Returns:
            dict: Dictionary containing positive and negative points as lists.
        """
        return {
            "positive_points": [point.to_list() for point in self.positive_points],
            "negative_points": [point.to_list() for point in self.negative_points],
        }
       
    

@dataclasses.dataclass
class Prompt:
    """Complete prompt for segment anything model including points and bounding box.
    
    Attributes:
        points (PointsPrompt): The point prompts (positive and negative).
        bounding_box (BoundingBox): The bounding box prompt.
    """
    points: PointsPrompt
    bounding_box: Optional[BoundingBox] = None
    
    def to_dict(self) -> dict:
        """Convert the complete prompt to a dictionary.
        
        Returns:
            dict: Dictionary containing all prompt information.
        """
        return {
            "points": self.points.to_dict(),
            "bounding_box": self.bounding_box.to_dict() if self.bounding_box is not None else [],
        }


def segment_anything_model_prompted(
    image: np.ndarray,
    prompts: list[Prompt] | Prompt,
    model_name: str,
    host: str,
    port: str,
    use_rest: bool = True,
    image_encoder: str = ".tif",
    decode_postprocessing: bool = True,
):
    """Perform segmentation using the Segment Anything model with prompts.
    
    Args:
        image (np.ndarray): Input image as a numpy array.
        prompts (list[Prompt] | Prompt): Single prompt or list of prompts for segmentation.
        model_name (str): Name of the model to use for inference.
        host (str): Host IP address of the inference server.
        port (str): Port number of the inference server.
        use_rest (bool, optional): Whether to use REST API instead of gRPC. Defaults to True.
        image_encoder (str, optional): Image encoding format. Defaults to ".tif".
        decode_postprocessing (bool, optional): Whether to decode the result. Defaults to True.
    
    Returns:
        list[list[SegmentAnythingResult]] | list: Segmentation results. If decode_postprocessing
            is True, returns decoded SegmentAnythingResult objects, otherwise raw results.
    """
    if isinstance(prompts, Prompt):
        prompts = [prompts]
    manager_class = TorchserveRestManager if use_rest else TorchserveGrpcManager
    manager = manager_class(
        host=host,
        inference_port=port,
        image_encoder=image_encoder,
    )
    result = manager.infer(
        model_name=model_name,
        image=image,
        prompts=json.dumps([prompt.to_dict() for prompt in prompts]),
    )
    if decode_postprocessing:
        return decode_segment_anything_result(result)
    return result if result is not None else []


def prepare_prompt_from_values(
    positive_points: Optional[list[list[float]]] = None, 
    negative_points: Optional[list[list[float]]] = None, 
    bounding_box: Optional[list[float]] = None
) -> Prompt:
    """Create a Prompt object from raw coordinate values.
    
    This function takes raw coordinate data and converts it into properly typed
    Prompt objects for use with the segment anything model.
    
    Args:
        positive_points (Optional[list[list[float]]], optional): List of [x, y] coordinates
            for positive prompt points. Defaults to None.
        negative_points (Optional[list[list[float]]], optional): List of [x, y] coordinates
            for negative prompt points. Defaults to None.
        bounding_box (Optional[list[float]], optional): Bounding box coordinates as
            [xstart, ystart, xend, yend]. Defaults to None.
    
    Returns:
        Prompt: A complete Prompt object ready for model inference.
        
    Raises:
        ValueError: If bounding box coordinates are invalid.
    """
    if bounding_box is not None:
        _validate_bounding_box(bounding_box)
        bounding_box = BoundingBox(
            xstart=bounding_box[0],
            ystart=bounding_box[1],
            xend=bounding_box[2],
            yend=bounding_box[3],
        )
    if positive_points is not None:
        positive_points = [Point(*point) for point in (positive_points or [])]
    if negative_points is not None:
        negative_points = [Point(*point) for point in (negative_points or [])]

    return prepare_prompt(positive_points, negative_points, bounding_box)


def prepare_prompt(
    positive_points: Optional[list[Point]] = None, 
    negative_points: Optional[list[Point]] = None, 
    bounding_box: Optional[BoundingBox] = None
) -> Prompt:
    """Create a Prompt object from typed Point and BoundingBox objects.
    
    Args:
        positive_points (Optional[list[Point]], optional): List of positive Point objects.
            Defaults to None.
        negative_points (Optional[list[Point]], optional): List of negative Point objects.
            Defaults to None.
        bounding_box (Optional[BoundingBox], optional): BoundingBox object. Defaults to None.
    
    Returns:
        Prompt: A complete Prompt object with all components initialized.
        
    Note:
        If any parameter is None, it will be replaced with an empty list or appropriate
        default value.
    """    
    
    if positive_points is None:
        positive_points = []
    if negative_points is None:
        negative_points = []
    
    return Prompt(
        points=PointsPrompt(
            positive_points=positive_points,
            negative_points=negative_points,
        ),
        bounding_box=bounding_box,
    )   


def decode_segment_anything_result(
    result: list[dict[str, str | float]] | None
) -> list[list[SegmentAnythingResult]]:
    """Decode raw segmentation results into SegmentAnythingResult objects.
    
    This function processes the raw output from the segment anything model and converts
    it into structured SegmentAnythingResult objects with decoded masks.
    
    Args:
        result (list[dict[str, str | float]] | None): Raw result from the model containing
            mask data and scores. Can be None if inference failed.
    
    Returns:
        list[list[SegmentAnythingResult]]: List of batches, where each batch contains
            a list of SegmentAnythingResult objects sorted by score (highest first).
            Returns empty list if result is None.
    """
    if result is None:
        return []
    decoded_result = []
    for batch in result:
        sorted_batch = sorted(batch, key=lambda x: x.get('score', 0.0), reverse=True)
        batch_result = []
        for mask_data in sorted_batch:
            mask = mask_data['mask']
            score = mask_data['score']
            batch_result.append(SegmentAnythingResult(mask=decode_base64_image(mask), score=score))
        decoded_result.append(batch_result)
    return decoded_result


def _validate_bounding_box(bounding_box: list[float]) -> None:
    """Validate that a bounding box has correct format and coordinates.
    
    Args:
        bounding_box (list[float]): Bounding box coordinates as [xstart, ystart, xend, yend].
    
    Raises:
        ValueError: If bounding box doesn't have exactly 4 coordinates or if
            coordinates are invalid (start >= end for either dimension).
    """
    if len(bounding_box) != 4:
        raise ValueError("Bounding box must have exactly 4 coordinates")
    if bounding_box[0] >= bounding_box[2] or bounding_box[1] >= bounding_box[3]:
        raise ValueError("Invalid bounding box coordinates")


if __name__ == "__main__":
    import cv2
    from matplotlib import pyplot as plt
    image = "/home/brani/tescan/data/lamella_location/images1/stem_bf_haadf_session43_window2_fov3000nm..png"
    image = cv2.imread(image, cv2.IMREAD_UNCHANGED)
    print(image.shape)
    prompt = prepare_prompt_from_values(
        positive_points=[[100, 100], [200, 200], [300, 300]],
        negative_points=[[400, 400], [500, 500], [600, 600]],
        bounding_box=[100, 100, 300, 300],
    )
    result = segment_anything_model_prompted(image, prompt, "SamModel", "192.168.50.148", "8080", decode_postprocessing=True)
    plt.imshow(result[0][0].mask)
    plt.show()