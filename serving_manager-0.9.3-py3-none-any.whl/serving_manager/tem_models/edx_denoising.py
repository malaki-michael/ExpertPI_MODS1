import base64
import json
from typing import NamedTuple

import cv2
import numpy as np

from .generic_handler_functions import InferenceClient


class EDXOutput(NamedTuple):
    denoised_edx_map: np.ndarray
    uncertainty_map: np.ndarray


class EDXInput(NamedTuple):
    edx_maps: dict[str, np.ndarray]
    stem_image: np.ndarray


def _encode(image, image_encoder):
    return base64.b64encode(cv2.imencode(image_encoder, image)[1]).decode("utf-8")


def _decode(base64_string):
    return cv2.imdecode(
        np.frombuffer(base64.b64decode(base64_string), dtype=np.uint8),
        cv2.IMREAD_UNCHANGED,
    )


def load_edx_inputs_from_paths(
    edx_maps_paths: dict[str, str],
    stem_image_path: str,
) -> EDXInput:
    """Loads EDX inputs from paths.

    Args:
        edx_maps_paths (dict[str, str]): Dictionary of EDX map names and paths.
        stem_image_path (str): Path to the stem image.

    Returns:
        EDXInput: EDX input tuple.
    """
    edx_images = {
        k: cv2.imread(path, cv2.IMREAD_UNCHANGED)
        for k, path in edx_maps_paths.items()
    }
    stem_image = cv2.imread(stem_image_path, cv2.IMREAD_UNCHANGED)

    return EDXInput(edx_images, stem_image)


def edx_denoising_model_from_paths(
    edx_maps_paths: dict[str, str],
    stem_image_path: str,
    model_name: str = "EDXDenoising",
    host: str = "localhost",
    port: str = "8000",
    image_encoder: str = ".tif",
    use_rest: bool = True
) -> dict[str, EDXOutput]:
    """Runs the EDX denoising model.

    Args:
        edx_maps_paths (dict[str, str]): Dictionary of EDX map names and paths.
        stem_image_path (str): Path to the stem image.
        model_name (str, optional): Name of the model. Defaults to "EDXDenoising".
        host (str, optional): Host of the model. Defaults to "localhost".
        port (str, optional): Port of the model. Defaults to "8000".
        image_encoder (str, optional): Image encoder. Defaults to ".tif".
        use_rest (bool, optional): Whether to use REST. Defaults to True.

    Returns:
        dict[str, EDXOutput]: Dictionary of EDX outputs.
    """
    edx_input = load_edx_inputs_from_paths(edx_maps_paths, stem_image_path)
    stem_image = edx_input.stem_image
    edx_maps = edx_input.edx_maps
    return edx_denoising_model(edx_maps, stem_image, model_name, host, port, image_encoder, use_rest)


def edx_denoising_model(
    edx_maps: dict[str, np.ndarray],
    stem_image: np.ndarray,
    model_name: str = "EDXDenoising",
    host: str = "localhost",
    port: str = "8000",
    image_encoder: str = ".tif",
    use_rest: bool = True
) -> dict[str, EDXOutput]:
    """Runs the EDX denoising model.

    Args:
        edx_maps (dict[str, np.ndarray]): Dictionary of EDX maps.
        stem_image (np.ndarray): Stem image.
        model_name (str, optional): Name of the model. Defaults to "EDXDenoising".
        host (str, optional): Host of the model. Defaults to "localhost".
        port (str, optional): Port of the model. Defaults to "8000".
        image_encoder (str, optional): Image encoder. Defaults to ".tif".
        use_rest (bool, optional): Whether to use REST. Defaults to True.

    Returns:
        dict[str, EDXOutput]: Dictionary of EDX outputs.
    """
    inference_client = InferenceClient(model_name, host, port, image_encoder=image_encoder, use_rest=use_rest)
    result = inference_client(
        image=stem_image,
        edx_maps=json.dumps({map_name: _encode(edx_map, image_encoder) for map_name, edx_map in edx_maps.items()}),
    )
    output = {
         map_name: EDXOutput(
             _decode(edx_map["denoised"]),
             _decode(edx_map["uncertainty"]),
         ) for map_name, edx_map in result.items()
   }

    return output