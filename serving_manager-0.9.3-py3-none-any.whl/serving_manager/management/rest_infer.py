import cv2
import niquests


def process_image(image, host, port, model_name):
    output = niquests.post(f"http://{host}:{port}/predictions/{model_name}",
                           data=cv2.imencode(".jpg", image)[1].tostring())
    return output.json()
